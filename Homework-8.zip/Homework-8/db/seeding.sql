INSERT INTO actor (actor_id, first_name, last_name, last_update)
VALUES(208,'bang', 'messi',NOW()),
(207, 'Salman', 'Khan', NOW()),
(204, 'John', 'Cena', NOW()),
(205, 'Sulaiman', 'Kahfi', NOW()),
(206, 'Ronaldo', 'Wati', NOW())

