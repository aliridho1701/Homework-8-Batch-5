/* Replace with your SQL commands */
-- SOAL NO. 3: Menambahkan kolom age pada table actor
ALTER TABLE actor
ADD COLUMN age VARCHAR